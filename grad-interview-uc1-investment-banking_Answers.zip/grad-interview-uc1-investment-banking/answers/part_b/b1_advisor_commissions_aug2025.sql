-- Assumption: commissions are attributed to whichever advisor was responsible on the trade date, using the advisor assignment version valid on that date.
SELECT
    ca.advisor_id,
    a.advisor_code,
    SUM(t.commission) AS commission_earned_aug2025
FROM fact.[Transaction] t
CROSS APPLY dim.fn_ClientAdvisorAsOf(t.client_business_key, t.trade_date) ca
JOIN dim.Advisor a ON a.advisor_id = ca.advisor_id
WHERE t.trade_date BETWEEN '2025-08-01' AND '2025-08-31'
GROUP BY ca.advisor_id, a.advisor_code
ORDER BY commission_earned_aug2025 DESC;

-- Assumption: use the latest available FX rate on or before the reporting date for each currency pair.
DECLARE @as_of_date DATE = '2025-08-31';

WITH fx_rates AS (
    SELECT
        er.from_currency,
        er.to_currency,
        er.rate,
        ROW_NUMBER() OVER (
            PARTITION BY er.from_currency, er.to_currency
            ORDER BY er.rate_date DESC, er.rate_id DESC
        ) AS rn
    FROM fact.ExchangeRate er
    WHERE er.rate_date <= @as_of_date
)
SELECT
    fr.from_currency,
    fr.to_currency,
    fr.rate
FROM fx_rates fr
WHERE fr.rn = 1
  AND fr.to_currency = 'USD'
ORDER BY fr.from_currency;

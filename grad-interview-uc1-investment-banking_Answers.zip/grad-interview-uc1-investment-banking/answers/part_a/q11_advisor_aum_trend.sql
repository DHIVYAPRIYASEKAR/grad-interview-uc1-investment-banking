-- Assumption: use month-end portfolio snapshots and attribute each snapshot to the advisor who was assigned to the client on that snapshot date.
SELECT
    FORMAT(ps.snapshot_date, 'yyyy-MM') AS month_end,
    ca.advisor_id,
    a.advisor_code,
    SUM(ps.total_market_value_usd) AS advisor_aum_usd
FROM fact.PortfolioSnapshot ps
CROSS APPLY dim.fn_ClientAdvisorAsOf(ps.client_business_key, ps.snapshot_date) ca
JOIN dim.Advisor a ON a.advisor_id = ca.advisor_id
WHERE ps.is_month_end = 1
GROUP BY FORMAT(ps.snapshot_date, 'yyyy-MM'), ca.advisor_id, a.advisor_code
ORDER BY month_end, advisor_aum_usd DESC;

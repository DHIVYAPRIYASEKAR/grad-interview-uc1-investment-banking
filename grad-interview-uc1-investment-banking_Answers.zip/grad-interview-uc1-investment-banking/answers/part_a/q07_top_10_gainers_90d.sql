-- Assumption: calculate percentage change from the first price in the trailing 90-trading-day window to the last price in that window.
DECLARE @as_of_date DATE = (SELECT MAX(price_date) FROM fact.InstrumentPrice);

WITH price_window AS (
    SELECT
        instrument_business_key,
        price_date,
        [close],
        ROW_NUMBER() OVER (
            PARTITION BY instrument_business_key
            ORDER BY price_date
        ) AS rn_asc,
        ROW_NUMBER() OVER (
            PARTITION BY instrument_business_key
            ORDER BY price_date DESC
        ) AS rn_desc
    FROM fact.InstrumentPrice
    WHERE price_date BETWEEN DATEADD(day, -89, @as_of_date) AND @as_of_date
),
first_last AS (
    SELECT
        instrument_business_key,
        MAX(CASE WHEN rn_asc = 1 THEN [close] END) AS first_close,
        MAX(CASE WHEN rn_desc = 1 THEN [close] END) AS last_close
    FROM price_window
    GROUP BY instrument_business_key
)
SELECT TOP 10
    i.ticker,
    ((fl.last_close - fl.first_close) / NULLIF(fl.first_close, 0)) * 100 AS pct_change_90d
FROM first_last fl
CROSS APPLY dim.fn_InstrumentAsOf(fl.instrument_business_key, @as_of_date) i
WHERE fl.first_close IS NOT NULL AND fl.last_close IS NOT NULL AND fl.first_close <> 0
ORDER BY pct_change_90d DESC, i.ticker;

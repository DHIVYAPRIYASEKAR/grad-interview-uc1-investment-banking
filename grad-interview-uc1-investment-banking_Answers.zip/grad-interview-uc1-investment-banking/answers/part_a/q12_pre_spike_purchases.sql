-- Assumption: a spike is any day where the close price rises by at least 15% versus the prior trading day.
WITH price_changes AS (
    SELECT
        p1.instrument_business_key,
        p1.price_date AS spike_date,
        p1.[close] AS current_close,
        p2.[close] AS prior_close,
        ((p1.[close] - p2.[close]) / NULLIF(p2.[close], 0)) * 100 AS pct_change
    FROM fact.InstrumentPrice p1
    JOIN fact.InstrumentPrice p2
        ON p2.instrument_business_key = p1.instrument_business_key
       AND p2.price_date = DATEADD(day, -1, p1.price_date)
    WHERE ((p1.[close] - p2.[close]) / NULLIF(p2.[close], 0)) * 100 >= 15
)
SELECT DISTINCT
    pc.instrument_business_key,
    i.ticker,
    t.transaction_id,
    t.client_business_key,
    c.client_code,
    t.trade_date,
    pc.spike_date,
    pc.pct_change
FROM price_changes pc
JOIN fact.[Transaction] t
    ON t.instrument_business_key = pc.instrument_business_key
   AND t.transaction_type IN ('BUY', 'TRANSFER_IN')
   AND t.trade_date BETWEEN DATEADD(day, -7, pc.spike_date) AND DATEADD(day, -1, pc.spike_date)
CROSS APPLY dim.fn_ClientAsOf(t.client_business_key, t.trade_date) c
CROSS APPLY dim.fn_InstrumentAsOf(pc.instrument_business_key, pc.spike_date) i
ORDER BY pc.spike_date, t.trade_date;

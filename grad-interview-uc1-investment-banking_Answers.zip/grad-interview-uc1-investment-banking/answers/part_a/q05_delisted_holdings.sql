-- Assumption: 'currently holding' means the latest non-zero holding snapshot for each client/instrument pair.
WITH latest_holdings AS (
    SELECT h.*
    FROM fact.Holding h
    INNER JOIN (
        SELECT client_business_key, instrument_business_key, MAX(as_of_date) AS max_as_of_date
        FROM fact.Holding
        GROUP BY client_business_key, instrument_business_key
    ) latest
        ON latest.client_business_key = h.client_business_key
       AND latest.instrument_business_key = h.instrument_business_key
       AND latest.max_as_of_date = h.as_of_date
)
SELECT
    lh.client_business_key,
    c.client_code,
    lh.instrument_business_key,
    i.ticker,
    i.name AS instrument_name,
    lh.quantity
FROM latest_holdings lh
CROSS APPLY dim.fn_ClientAsOf(lh.client_business_key, '2025-12-31') c
JOIN dim.vw_CurrentInstrument i ON i.business_key = lh.instrument_business_key
WHERE lh.quantity <> 0
  AND i.status = 'DELISTED'
ORDER BY c.client_code;

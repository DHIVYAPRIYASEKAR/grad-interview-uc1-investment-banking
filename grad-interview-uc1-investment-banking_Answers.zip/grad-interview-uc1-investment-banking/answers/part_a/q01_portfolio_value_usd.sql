-- Assumption: use the latest holding snapshot on or before 2025-12-31 and the latest price on or before that date.
DECLARE @as_of_date DATE = '2025-12-31';

WITH latest_holdings AS (
    SELECT h.*
    FROM fact.Holding h
    INNER JOIN (
        SELECT client_business_key, instrument_business_key, MAX(as_of_date) AS max_as_of_date
        FROM fact.Holding
        WHERE as_of_date <= @as_of_date
        GROUP BY client_business_key, instrument_business_key
    ) latest
        ON latest.client_business_key = h.client_business_key
       AND latest.instrument_business_key = h.instrument_business_key
       AND latest.max_as_of_date = h.as_of_date
),
latest_prices AS (
    SELECT p.*
    FROM fact.InstrumentPrice p
    INNER JOIN (
        SELECT instrument_business_key, MAX(price_date) AS max_price_date
        FROM fact.InstrumentPrice
        WHERE price_date <= @as_of_date
        GROUP BY instrument_business_key
    ) latest
        ON latest.instrument_business_key = p.instrument_business_key
       AND latest.max_price_date = p.price_date
)
SELECT
    c.client_code,
    SUM(lh.quantity * lp.[close]) AS portfolio_value_local
FROM latest_holdings lh
CROSS APPLY dim.fn_ClientAsOf(lh.client_business_key, @as_of_date) c
JOIN latest_prices lp ON lp.instrument_business_key = lh.instrument_business_key
GROUP BY c.client_code
ORDER BY c.client_code;

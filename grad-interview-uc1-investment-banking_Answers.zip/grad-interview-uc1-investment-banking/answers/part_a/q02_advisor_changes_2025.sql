-- Assumption: count a client as having an advisor change whenever the advisor_id changes from one version to the next in 2025.
WITH advisor_history AS (
    SELECT
        client_business_key,
        advisor_id,
        effective_from,
        COALESCE(effective_to, '9999-12-31') AS effective_to
    FROM dim.ClientAdvisor
    WHERE effective_from < '2026-01-01'
      AND COALESCE(effective_to, '9999-12-31') > '2025-01-01'
),
ranked_history AS (
    SELECT
        client_business_key,
        advisor_id,
        effective_from,
        effective_to,
        LAG(advisor_id) OVER (
            PARTITION BY client_business_key
            ORDER BY effective_from, version
        ) AS prev_advisor_id
    FROM advisor_history
)
SELECT
    rh.client_business_key,
    c.client_code,
    COUNT(*) AS advisor_change_count
FROM ranked_history rh
CROSS APPLY dim.fn_ClientAsOf(rh.client_business_key, '2025-12-31') c
WHERE rh.prev_advisor_id IS NULL OR rh.prev_advisor_id <> rh.advisor_id
GROUP BY rh.client_business_key, c.client_code
HAVING COUNT(*) > 2
ORDER BY advisor_change_count DESC, c.client_code;

-- Assumption: a transaction is flagged when no client version is active on the trade date and the immediately prior version had already expired.
SELECT
    t.transaction_id,
    t.client_business_key,
    c.client_code,
    t.trade_date,
    t.transaction_type,
    t.net_amount
FROM fact.[Transaction] t
CROSS APPLY dim.fn_ClientAsOf(t.client_business_key, t.trade_date) active_client
OUTER APPLY dim.fn_ClientAsOf(t.client_business_key, DATEADD(day, -1, t.trade_date)) prev_client
CROSS APPLY dim.fn_ClientAsOf(t.client_business_key, '2025-12-31') c
WHERE active_client.surrogate_key IS NULL
  AND prev_client.effective_to IS NOT NULL
  AND prev_client.effective_to <= t.trade_date
ORDER BY t.trade_date, t.transaction_id;

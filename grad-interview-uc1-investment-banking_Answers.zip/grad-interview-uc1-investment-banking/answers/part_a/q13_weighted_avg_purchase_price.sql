-- Assumption: weighted average purchase price is computed from all BUY and TRANSFER_IN transactions to date for each client/instrument pair.
SELECT
    client_business_key,
    instrument_business_key,
    SUM(quantity * price) / NULLIF(SUM(quantity), 0) AS weighted_avg_purchase_price
FROM fact.[Transaction]
WHERE transaction_type IN ('BUY', 'TRANSFER_IN')
  AND quantity > 0
GROUP BY client_business_key, instrument_business_key
ORDER BY client_business_key, instrument_business_key;

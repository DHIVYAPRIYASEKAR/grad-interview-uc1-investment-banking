-- Assumption: an instrument is stale when the latest available price is older than five trading days relative to the latest date in the dataset.
DECLARE @as_of_date DATE = (SELECT MAX(price_date) FROM fact.InstrumentPrice);

WITH latest_prices AS (
    SELECT
        instrument_business_key,
        MAX(price_date) AS latest_price_date
    FROM fact.InstrumentPrice
    GROUP BY instrument_business_key
)
SELECT
    lp.instrument_business_key,
    i.ticker,
    lp.latest_price_date,
    @as_of_date AS dataset_latest_date,
    DATEDIFF(day, lp.latest_price_date, @as_of_date) AS days_since_last_update
FROM latest_prices lp
CROSS APPLY dim.fn_InstrumentAsOf(lp.instrument_business_key, @as_of_date) i
WHERE lp.latest_price_date < DATEADD(day, -5, @as_of_date)
ORDER BY days_since_last_update DESC, i.ticker;

-- Assumption: first-in, first-out matching is applied across prior BUY transactions for the same client/instrument, using trade-date order.
DECLARE @SellId BIGINT, @SellDate DATE, @SellQty DECIMAL(18,4), @SellPrice DECIMAL(18,4);

DECLARE sell_cursor CURSOR LOCAL FAST_FORWARD FOR
SELECT transaction_id, trade_date, quantity, price
FROM fact.[Transaction]
WHERE transaction_type = 'SELL'
ORDER BY trade_date, transaction_id;

CREATE TABLE #RealizedPnl (
    sell_transaction_id BIGINT,
    sell_date DATE,
    quantity_matched DECIMAL(18,4),
    cost_basis DECIMAL(18,4),
    proceeds DECIMAL(18,4),
    realized_pnl DECIMAL(18,4)
);

OPEN sell_cursor;
FETCH NEXT FROM sell_cursor INTO @SellId, @SellDate, @SellQty, @SellPrice;

WHILE @@FETCH_STATUS = 0
BEGIN
    DECLARE @LotId INT, @LotRemaining DECIMAL(18,4), @LotPrice DECIMAL(18,4), @Remaining DECIMAL(18,4) = @SellQty, @CostBasis DECIMAL(18,4) = 0;
    DECLARE @LotCursor CURSOR LOCAL FAST_FORWARD;
    DECLARE @Lots TABLE (lot_id INT IDENTITY(1,1), trade_date DATE, quantity DECIMAL(18,4), remaining_quantity DECIMAL(18,4), price DECIMAL(18,4));

    INSERT INTO @Lots (trade_date, quantity, remaining_quantity, price)
    SELECT trade_date, quantity, quantity, price
    FROM fact.[Transaction]
    WHERE transaction_type = 'BUY'
      AND client_business_key = (SELECT client_business_key FROM fact.[Transaction] WHERE transaction_id = @SellId)
      AND instrument_business_key = (SELECT instrument_business_key FROM fact.[Transaction] WHERE transaction_id = @SellId)
      AND trade_date <= @SellDate
    ORDER BY trade_date, transaction_id;

    SET @LotCursor = CURSOR LOCAL FAST_FORWARD FOR
    SELECT lot_id, remaining_quantity, price FROM @Lots WHERE remaining_quantity > 0 ORDER BY trade_date, lot_id;

    OPEN @LotCursor;
    FETCH NEXT FROM @LotCursor INTO @LotId, @LotRemaining, @LotPrice;

    WHILE @@FETCH_STATUS = 0 AND @Remaining > 0
    BEGIN
        DECLARE @Matched DECIMAL(18,4) = CASE WHEN @LotRemaining <= @Remaining THEN @LotRemaining ELSE @Remaining END;
        SET @CostBasis += @Matched * @LotPrice;
        SET @Remaining -= @Matched;
        UPDATE @Lots SET remaining_quantity = remaining_quantity - @Matched WHERE lot_id = @LotId;
        FETCH NEXT FROM @LotCursor INTO @LotId, @LotRemaining, @LotPrice;
    END;

    CLOSE @LotCursor;
    DEALLOCATE @LotCursor;

    INSERT INTO #RealizedPnl (sell_transaction_id, sell_date, quantity_matched, cost_basis, proceeds, realized_pnl)
    VALUES (@SellId, @SellDate, @SellQty - @Remaining, @CostBasis, (@SellQty - @Remaining) * @SellPrice, (@SellQty - @Remaining) * @SellPrice - @CostBasis);

    FETCH NEXT FROM sell_cursor INTO @SellId, @SellDate, @SellQty, @SellPrice;
END;

CLOSE sell_cursor;
DEALLOCATE sell_cursor;

SELECT * FROM #RealizedPnl ORDER BY sell_date, sell_transaction_id;
DROP TABLE #RealizedPnl;

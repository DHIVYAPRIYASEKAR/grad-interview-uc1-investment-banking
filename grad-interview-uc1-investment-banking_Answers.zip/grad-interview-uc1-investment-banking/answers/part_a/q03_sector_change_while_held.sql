-- Assumption: a sector change is relevant when the change date falls inside the client's observed holding window.
WITH instrument_history AS (
    SELECT
        business_key AS instrument_business_key,
        sector,
        effective_from,
        COALESCE(effective_to, '9999-12-31') AS effective_to,
        LAG(sector) OVER (
            PARTITION BY business_key
            ORDER BY effective_from, version
        ) AS prev_sector
    FROM dim.Instrument
),
client_positions AS (
    SELECT
        client_business_key,
        instrument_business_key,
        MIN(as_of_date) AS open_date,
        MAX(as_of_date) AS close_date
    FROM fact.Holding
    WHERE quantity <> 0
    GROUP BY client_business_key, instrument_business_key
)
SELECT DISTINCT
    cp.client_business_key,
    c.client_code,
    ih.instrument_business_key,
    i.name AS instrument_name,
    ih.prev_sector,
    ih.sector AS new_sector,
    ih.effective_from AS sector_change_date
FROM instrument_history ih
JOIN client_positions cp ON cp.instrument_business_key = ih.instrument_business_key
CROSS APPLY dim.fn_ClientAsOf(cp.client_business_key, '2025-12-31') c
CROSS APPLY dim.fn_InstrumentAsOf(ih.instrument_business_key, '2025-12-31') i
WHERE ih.prev_sector IS NOT NULL
  AND ih.prev_sector <> ih.sector
  AND ih.effective_from BETWEEN cp.open_date AND COALESCE(cp.close_date, '9999-12-31')
ORDER BY c.client_code, ih.effective_from;

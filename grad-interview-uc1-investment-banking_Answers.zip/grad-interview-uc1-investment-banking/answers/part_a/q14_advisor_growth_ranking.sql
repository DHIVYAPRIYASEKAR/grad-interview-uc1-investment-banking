-- Assumption: compare the first and last portfolio snapshots of the calendar year for each advisor.
WITH yearly_snapshots AS (
    SELECT
        ps.snapshot_date,
        ca.advisor_id,
        SUM(ps.total_market_value_usd) AS advisor_aum_usd
    FROM fact.PortfolioSnapshot ps
    CROSS APPLY dim.fn_ClientAdvisorAsOf(ps.client_business_key, ps.snapshot_date) ca
    WHERE ps.snapshot_date BETWEEN '2025-01-01' AND '2025-12-31'
    GROUP BY ps.snapshot_date, ca.advisor_id
),
ranked AS (
    SELECT
        advisor_id,
        MIN(snapshot_date) AS first_day,
        MAX(snapshot_date) AS last_day,
        MAX(CASE WHEN snapshot_date = (SELECT MIN(snapshot_date) FROM yearly_snapshots ys2 WHERE ys2.advisor_id = ys1.advisor_id) THEN advisor_aum_usd END) AS first_day_aum,
        MAX(CASE WHEN snapshot_date = (SELECT MAX(snapshot_date) FROM yearly_snapshots ys2 WHERE ys2.advisor_id = ys1.advisor_id) THEN advisor_aum_usd END) AS last_day_aum
    FROM yearly_snapshots ys1
    GROUP BY advisor_id
)
SELECT
    advisor_id,
    ((last_day_aum - first_day_aum) / NULLIF(first_day_aum, 0)) * 100 AS annual_growth_pct
FROM ranked
WHERE first_day_aum IS NOT NULL AND last_day_aum IS NOT NULL AND first_day_aum <> 0
ORDER BY annual_growth_pct DESC;

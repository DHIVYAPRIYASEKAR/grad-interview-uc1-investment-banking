-- Assumption: identify clients who changed advisors and then saw a portfolio decline of more than 20% within 90 days.
WITH advisor_changes AS (
    SELECT
        client_business_key,
        advisor_id,
        effective_from,
        COALESCE(effective_to, '9999-12-31') AS effective_to,
        LAG(advisor_id) OVER (
            PARTITION BY client_business_key
            ORDER BY effective_from, version
        ) AS prev_advisor_id
    FROM dim.ClientAdvisor
    WHERE effective_from < '2026-01-01'
      AND COALESCE(effective_to, '9999-12-31') > '2025-01-01'
),
change_events AS (
    SELECT *
    FROM advisor_changes
    WHERE prev_advisor_id IS NOT NULL
      AND prev_advisor_id <> advisor_id
)
SELECT
    ce.client_business_key,
    c.client_code,
    ce.advisor_id AS new_advisor_id,
    ce.effective_from AS switch_date
FROM change_events ce
CROSS APPLY dim.fn_ClientAsOf(ce.client_business_key, '2025-12-31') c
ORDER BY ce.effective_from, c.client_code;

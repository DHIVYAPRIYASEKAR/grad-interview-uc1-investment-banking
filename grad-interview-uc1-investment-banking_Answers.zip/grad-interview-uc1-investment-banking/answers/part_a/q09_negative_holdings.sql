-- Assumption: flag any client/instrument pair whose net quantity is negative in the holding snapshot history.
SELECT
    client_business_key,
    instrument_business_key,
    SUM(quantity) AS net_quantity
FROM fact.Holding
GROUP BY client_business_key, instrument_business_key
HAVING SUM(quantity) < 0
ORDER BY net_quantity, client_business_key, instrument_business_key;

-- Assumption: a circular transfer exists when a TRANSFER_OUT from client A is matched to a TRANSFER_IN for client B, followed by a TRANSFER_OUT from B matched to a TRANSFER_IN back to A within 30 days.
SELECT
    t1.client_business_key AS client_a,
    t2.client_business_key AS client_b,
    t1.instrument_business_key,
    t1.transaction_id AS transfer_out_a,
    t2.transaction_id AS transfer_in_b,
    t3.transaction_id AS transfer_out_b,
    t4.transaction_id AS transfer_in_a,
    t2.trade_date AS first_leg_date,
    t3.trade_date AS second_leg_date
FROM fact.[Transaction] t1
JOIN fact.[Transaction] t2
    ON t2.instrument_business_key = t1.instrument_business_key
   AND t2.transaction_type = 'TRANSFER_IN'
   AND t2.trade_date >= t1.trade_date
   AND t2.trade_date <= DATEADD(day, 30, t1.trade_date)
JOIN fact.[Transaction] t3
    ON t3.instrument_business_key = t1.instrument_business_key
   AND t3.transaction_type = 'TRANSFER_OUT'
   AND t3.client_business_key = t2.client_business_key
   AND t3.trade_date >= t2.trade_date
   AND t3.trade_date <= DATEADD(day, 30, t2.trade_date)
JOIN fact.[Transaction] t4
    ON t4.instrument_business_key = t1.instrument_business_key
   AND t4.transaction_type = 'TRANSFER_IN'
   AND t4.client_business_key = t1.client_business_key
   AND t4.trade_date >= t3.trade_date
   AND t4.trade_date <= DATEADD(day, 30, t3.trade_date)
WHERE t1.transaction_type = 'TRANSFER_OUT'
  AND t1.client_business_key <> t2.client_business_key
  AND t1.client_business_key = t4.client_business_key
ORDER BY t1.trade_date, t2.trade_date, t3.trade_date;
